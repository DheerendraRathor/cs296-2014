Group Number : 12
Group Members:
1. Vikas Garg : 120050017
2. Ravi Kumar Verma : 120050027
3. Dheerendra Singh Rathor : 120050033

Resources:
http://stackoverflow.com/questions/6618705/replace-first-two-whitespace-occurrences-with-a-comma-using-sed
http://www.grymoire.com/Unix/Sed.html#uh-0
http://stackoverflow.com/questions/1917557/how-to-replace-the-last-one-or-two-characters-of-a-file-with-unix-tools
http://unix.stackexchange.com/questions/114244/replace-all-newlines-to-space-except-the-last
http://www.delorie.com/gnu/docs/gawk/gawk_134.html
http://stackoverflow.com/questions/18432370/how-to-plot-graph-with-calculating-average-on-abscissa-in-gnuplot
http://stackoverflow.com/questions/11314751/fit-straight-lines-with-gnuplot
http://www.cs.grinnell.edu/~weinman/courses/CSC213/2008F/labs/10-pingpong-regression.pdf
http://stackoverflow.com/questions/14871272/how-to-plot-a-csv-file-in-gnuplot
http://gnuplot-surprising.blogspot.in/2011/09/plot-histograms-using-boxes.html
http://stackoverflow.com/questions/2471884/histogram-using-gnuplot
Googling is always helpful as usual.

All work is completed by us and we have not copied it from anywhere.

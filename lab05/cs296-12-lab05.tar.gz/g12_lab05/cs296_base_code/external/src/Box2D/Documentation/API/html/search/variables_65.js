var searchData=
[
  ['enablelimit',['enableLimit',['../structb2_prismatic_joint_def.html#aa61a03b68caac62a5cf66354f6756eae',1,'b2PrismaticJointDef::enableLimit()'],['../structb2_revolute_joint_def.html#a2eaefc5fc5caf879cfd59ebcd852b756',1,'b2RevoluteJointDef::enableLimit()']]],
  ['enablemotor',['enableMotor',['../structb2_prismatic_joint_def.html#a58ac79a54a8110d3a745e1d6d36990dc',1,'b2PrismaticJointDef::enableMotor()'],['../structb2_revolute_joint_def.html#aa94d9e66be9f03818d0cfbd9c70b2996',1,'b2RevoluteJointDef::enableMotor()'],['../structb2_wheel_joint_def.html#a8e7193d6c34c784ffd71e79d3a70acc6',1,'b2WheelJointDef::enableMotor()']]]
];
